STEPS:
1.Before running server we need to set environment veriable.

For ex:
C:\Users\Suma\OneDrive\Desktop\project1\blog>workon geek

(geek) C:\Users\Suma\OneDrive\Desktop\project1\blog>py manage.py runserver
Watching for file changes with StatReloader
Performing system checks...

System check identified no issues (0 silenced).
June 21, 2021 - 20:59:12
Django version 3.2.4, using settings 'blog.settings'
Starting development server at http://127.0.0.1:8000/
Quit the server with CTRL-BREAK.

If we directly run the server that time it will give "module name not found" error .



















